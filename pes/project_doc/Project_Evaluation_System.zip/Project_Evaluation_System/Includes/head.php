<!DOCTYPE html>
<html>
	<head>
		<title>Alpha</title>
		<meta charset="utf-8"/>
		<meta name="viewport" content="width=device-width, initial-scale=1"/>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="keywords" content="Resort Inn Responsive , Smartphone Compatible web template , Samsung, LG, Sony Ericsson, Motorola web design" />
		<link rel="stylesheet" href="../Bootstrap/css/bootstrap.min.css"/>
		<script src="../Bootstrap/js/jquery-3.3.1.min.js"></script>
		<script src="../Bootstrap/js/bootstrap.min.js"></script>