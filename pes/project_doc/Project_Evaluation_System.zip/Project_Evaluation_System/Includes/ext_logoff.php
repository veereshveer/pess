<?php
	session_start();
	unset($_SESSION['ext_email']);
	echo "<script>window.open('../External/login.php','_self');</script>";
?>