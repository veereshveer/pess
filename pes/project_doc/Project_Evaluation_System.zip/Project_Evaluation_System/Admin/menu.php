<div class="container text-center">
	<ul class="nav navbar-nav" style="background-color:rgba(55,55,15,0.3);width:100%">
		<li><a style="color:orange;font-family:Comic Sans MS" href="add_internal.php"><h4><b>Add Internal</b></h4></a></li>
		<li><a style="color:orange;font-family:Comic Sans MS" href="intdtl.php"><h4><b>Internal Details</b></h4> <span class="sr-only">(current)</span></a></li>
		<li><a style="color:orange;font-family:Comic Sans MS" href="stdtl.php"><h4><b>Student Details</b></h4></a></li>
		<li><a style="color:orange;font-family:Comic Sans MS" href="add_external.php"><h4><b>Add External</b> </h4></a></li>
		<li><a style="color:orange;font-family:Comic Sans MS" href="extdtl.php"><h4><b>External Details</b> </h4></a></li>
		<li><a style="color:orange;font-family:Comic Sans MS" href="result.php"><h4><b>Final Result</b> </h4></a></li>
	</ul>
</div>