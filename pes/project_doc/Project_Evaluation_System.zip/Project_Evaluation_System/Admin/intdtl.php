<?php
	session_start();
	if(isset($_SESSION['adm_email'])){
	require('../Includes/head.php');
	require('../Db/db.php');
?>
	</head>
	<body style="background-image:url(../images/643482.jpg);background-attachment:fixed;background-position:center;background-size:cover;">
		<?php require_once('menu.php'); ?>
		<div class="container-fluid" style="width:100%;color:black;">
		<!--<h3>Internal details</h3>-->
			<table class="table table-striped table-hover table-bordered" border="1" style="border-color:black;">
				<tr class="warning"><!--<th>check</th>-->
					<th>Name</th>
					<th>Dept</th>
					<th>Branch</th>
					<th>Email</th>
				</tr>
			<?php
			 $query = mysqli_query($con,'select * from int_details'); 
			 $num = mysqli_num_rows($query);
			while($num){
			$data=mysqli_fetch_row($query);
			echo "<tr>
					   <!--<th><input type='checkbox' name='ckeck'/></th>-->
						<th>$data[0]</th>
						<th>$data[1]</th>
						<th>$data[2]</th>
						<th>$data[3]</th>
			</tr>";
			$num--;
			}
			?>
			</table>
			<form method="post">
				<input class="btn btn-info" type="submit" value="Send Link" name="submit"/>
			</form>
		</div>
	</body>
</html>
<?php
	if(isset($_POST['submit'])){
		$query="select email from int_details";
		$exec=mysqli_query($con,$query) or die("Error");
		while($val=mysqli_fetch_row($exec)){
			echo "<script>alert('$val[0]');</script>";
			$subject = 'SIGNUP LIN';
			$messege = "pes/Internal/";
			$headers = 'From: DrAIT_Autonomous';
			@mail($to,$subject,$messege,$headers);
		}
	}
 }else{
	echo "<script>window.open('login.php','_self')</script>";
}