<?php
	function sendlinkext(){
		$code=http://localhost/aniveer/internal/login.php
		$to=$_POST['email'];
		$messege = $code;
		$headers = 'From: noreply';
		@mail($to,$subject,$messege,$headers);
	}
?>