<?php
	$con = mysqli_connect("localhost","root","","pes") or die("Error in Database Connection");
?>